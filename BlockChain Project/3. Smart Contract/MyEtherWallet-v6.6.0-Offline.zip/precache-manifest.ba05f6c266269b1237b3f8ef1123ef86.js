self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2a8bf02e75c54015c0b000b10c42d45b",
    "url": ".well-known/security.txt"
  },
  {
    "revision": "863cf7cd62b0031b6c4c",
    "url": "css/chunk-062539e4.796b61e7.css"
  },
  {
    "revision": "6d931b592a53533303c4",
    "url": "css/chunk-340c87db.4f10adee.css"
  },
  {
    "revision": "e4d95b360bd238f60566",
    "url": "css/chunk-5b853063.49f3188c.css"
  },
  {
    "revision": "531d08620a538334fa07",
    "url": "css/chunk-5b8767bd.06fcb1cf.css"
  },
  {
    "revision": "67b9440b55137775cbd1",
    "url": "css/chunk-715342ac.7c3769c3.css"
  },
  {
    "revision": "f4eb9e6b2abe7591ed60",
    "url": "css/chunk-8e5acde4.29ab260f.css"
  },
  {
    "revision": "b3816157884fe4fa7a22",
    "url": "css/chunk-e5a65756.016e0b00.css"
  },
  {
    "revision": "61fcbdbe4c1fde642b6e688b7e1e5b4a",
    "url": "favicon.png"
  },
  {
    "revision": "0a2d736efa9f1e8e4656a1bcce9280e6",
    "url": "fonts/materialdesignicons-webfont.0a2d736e.eot"
  },
  {
    "revision": "0e77e9c840132a335542552151bc1fe8",
    "url": "fonts/materialdesignicons-webfont.0e77e9c8.ttf"
  },
  {
    "revision": "3ac50b5b36eb2f11b000dce1792d0bb0",
    "url": "fonts/materialdesignicons-webfont.3ac50b5b.ttf"
  },
  {
    "revision": "62ff6e3aa8fe89abb298262eeadc357f",
    "url": "fonts/materialdesignicons-webfont.62ff6e3a.woff2"
  },
  {
    "revision": "7ec5dab7e7ff250971d2ff50379778dc",
    "url": "fonts/materialdesignicons-webfont.7ec5dab7.woff2"
  },
  {
    "revision": "a0d13d16cc2f3647680d9f1ff003f58b",
    "url": "fonts/materialdesignicons-webfont.a0d13d16.woff"
  },
  {
    "revision": "a32fa1f27abbfa96ff2f79e1ade723d5",
    "url": "fonts/materialdesignicons-webfont.a32fa1f2.eot"
  },
  {
    "revision": "d7928196ce1d1b1c246e499d6b3cef7b",
    "url": "fonts/materialdesignicons-webfont.d7928196.woff"
  },
  {
    "revision": "5cb7edfceb233100075dc9a1e12e8da3",
    "url": "fonts/roboto-v20-latin-100.5cb7edfc.woff"
  },
  {
    "revision": "6906d86d9bc67920de4234d88edbc6d9",
    "url": "fonts/roboto-v20-latin-100.6906d86d.eot"
  },
  {
    "revision": "7370c3679472e9560965ff48a4399d0b",
    "url": "fonts/roboto-v20-latin-100.7370c367.woff2"
  },
  {
    "revision": "ff1e90ce3376de433388ec3fc415aa0f",
    "url": "fonts/roboto-v20-latin-100.ff1e90ce.ttf"
  },
  {
    "revision": "806854d4422d0bd79e0f8c87c329a568",
    "url": "fonts/roboto-v20-latin-300.806854d4.ttf"
  },
  {
    "revision": "b00849e00f4c2331cddd8ffb44a6720b",
    "url": "fonts/roboto-v20-latin-300.b00849e0.woff"
  },
  {
    "revision": "bda729dbf749cbb9a8e480fa2deec2e9",
    "url": "fonts/roboto-v20-latin-300.bda729db.eot"
  },
  {
    "revision": "ef7c6637c68f269a882e73bcb57a7f6a",
    "url": "fonts/roboto-v20-latin-300.ef7c6637.woff2"
  },
  {
    "revision": "020c97dc8e0463259c2f9df929bb0c69",
    "url": "fonts/roboto-v20-latin-500.020c97dc.woff2"
  },
  {
    "revision": "260c8072feca314957defd2ad4ccc0ee",
    "url": "fonts/roboto-v20-latin-500.260c8072.eot"
  },
  {
    "revision": "87284894879f5b1c229cb49c8ff6decc",
    "url": "fonts/roboto-v20-latin-500.87284894.woff"
  },
  {
    "revision": "8c608256fb0273e3a36e6b603f71f213",
    "url": "fonts/roboto-v20-latin-500.8c608256.ttf"
  },
  {
    "revision": "2735a3a69b509faf3577afd25bdf552e",
    "url": "fonts/roboto-v20-latin-700.2735a3a6.woff2"
  },
  {
    "revision": "4570b93ae0caba2b938e2ddf091099ea",
    "url": "fonts/roboto-v20-latin-700.4570b93a.eot"
  },
  {
    "revision": "96559ffb5be917f1ce9f748bf4f34732",
    "url": "fonts/roboto-v20-latin-700.96559ffb.ttf"
  },
  {
    "revision": "adcde98f1d584de52060ad7b16373da3",
    "url": "fonts/roboto-v20-latin-700.adcde98f.woff"
  },
  {
    "revision": "22acb397075fc000039235655d658600",
    "url": "fonts/roboto-v20-latin-900.22acb397.ttf"
  },
  {
    "revision": "352cf1ddd096799baa560159884fb515",
    "url": "fonts/roboto-v20-latin-900.352cf1dd.eot"
  },
  {
    "revision": "9b3766ef4a402ad3fdeef7501a456512",
    "url": "fonts/roboto-v20-latin-900.9b3766ef.woff2"
  },
  {
    "revision": "bb1e4dc6333675d11ada2e857e7f95d7",
    "url": "fonts/roboto-v20-latin-900.bb1e4dc6.woff"
  },
  {
    "revision": "329ae1c377b1fb667f5be6abd50327fc",
    "url": "fonts/roboto-v20-latin-regular.329ae1c3.ttf"
  },
  {
    "revision": "479970ffb74f2117317f9d24d9e317fe",
    "url": "fonts/roboto-v20-latin-regular.479970ff.woff2"
  },
  {
    "revision": "4be1a572fca40bcb2202504cb17aed91",
    "url": "fonts/roboto-v20-latin-regular.4be1a572.eot"
  },
  {
    "revision": "60fa3c0614b8fb2f394fa29944c21540",
    "url": "fonts/roboto-v20-latin-regular.60fa3c06.woff"
  },
  {
    "revision": "bd0e4b0f94cc598aac4271ef9b436fac",
    "url": "icons/android-chrome-192x192.png"
  },
  {
    "revision": "5c3f4f5a767158cbb40860c5abc98e5d",
    "url": "icons/android-chrome-512x512.png"
  },
  {
    "revision": "249c7d47c0e74e732425e3c5ae85c863",
    "url": "icons/apple-touch-icon-120x120.png"
  },
  {
    "revision": "c593277cf5779720db2adbfb3aae072f",
    "url": "icons/apple-touch-icon-152x152.png"
  },
  {
    "revision": "9b02a72b8c3770760bc60919e637d45c",
    "url": "icons/apple-touch-icon-180x180.png"
  },
  {
    "revision": "970f2941076569ea2b7c7dd83a3509a6",
    "url": "icons/apple-touch-icon-60x60.png"
  },
  {
    "revision": "676e76fb337fc9ad68ed9a9c00d92fac",
    "url": "icons/apple-touch-icon-76x76.png"
  },
  {
    "revision": "a8c4cea5a22ecfdb59cf2b463ea581a5",
    "url": "icons/apple-touch-icon.png"
  },
  {
    "revision": "5456fd1d3a46a1fcbe0e133dfa9924e0",
    "url": "icons/favicon-16x16.png"
  },
  {
    "revision": "775f0e4f9a7d4ddc94b60f79e67e0a24",
    "url": "icons/favicon-32x32.png"
  },
  {
    "revision": "e91b3266af8075cfd4172fca87688490",
    "url": "icons/icon192.png"
  },
  {
    "revision": "0279aae5bee03dd78532beeaf142ad82",
    "url": "icons/msapplication-icon-144x144.png"
  },
  {
    "revision": "1887fd97619a9a361c1ead579c7518bf",
    "url": "icons/mstile-150x150.png"
  },
  {
    "revision": "1a39deb07f580bfe50f2095c8491dcc5",
    "url": "icons/safari-pinned-tab.svg"
  },
  {
    "revision": "1d8b91cf791ca22a711b0e03301d8bab",
    "url": "img/1inch.1d8b91cf.png"
  },
  {
    "revision": "730ed530612ef984039fcef57ba0f87d",
    "url": "img/Changelly.730ed530.png"
  },
  {
    "revision": "050a40e7631a85a54f788300e6c9d55a",
    "url": "img/Curve.050a40e7.png"
  },
  {
    "revision": "e56dc6a3bd81c775d85d43d139041515",
    "url": "img/Ledger-Nano-X-Label-Icon.e56dc6a3.svg"
  },
  {
    "revision": "2b2b812ad8ce66825779916df753a5b0",
    "url": "img/Ledger-Nano-X-image.2b2b812a.svg"
  },
  {
    "revision": "3c6d4bb520d5d3c3ebe406d18cdea5c7",
    "url": "img/Sushiswap.3c6d4bb5.png"
  },
  {
    "revision": "73c82235c38e3da1bd8dd1b6c11a6643",
    "url": "img/Synthetix.73c82235.png"
  },
  {
    "revision": "36ab476e5e55f496749ee61897a9cfb5",
    "url": "img/USD.36ab476e.svg"
  },
  {
    "revision": "dfeb0f940880884d11f30ebceef464be",
    "url": "img/ae.dfeb0f94.svg"
  },
  {
    "revision": "5ce6cd72be6763228940e78d13e2cac4",
    "url": "img/af.5ce6cd72.svg"
  },
  {
    "revision": "244afce9ac99c9f215ec7d4aa16dacd5",
    "url": "img/al.244afce9.svg"
  },
  {
    "revision": "d0b63a1627e0bb26b04f4b16befed322",
    "url": "img/alex.d0b63a16.jpg"
  },
  {
    "revision": "3367445df6aacf4268a867f54b2aa012",
    "url": "img/am.3367445d.svg"
  },
  {
    "revision": "4ebca01588f68ef7087ed2bca34c79f9",
    "url": "img/andrew-dao.4ebca015.jpg"
  },
  {
    "revision": "44e0cfb1d3fb73bda82d1a352f57e057",
    "url": "img/andrew.44e0cfb1.jpg"
  },
  {
    "revision": "5b8624837922c3b279072b0b1cf3c43d",
    "url": "img/ao.5b862483.svg"
  },
  {
    "revision": "50bcaaec8c29006da8cabe0b097d9847",
    "url": "img/ar.50bcaaec.svg"
  },
  {
    "revision": "857cd69f38bde448dd185e9956b98561",
    "url": "img/au.857cd69f.svg"
  },
  {
    "revision": "d536ae24c11b08eef9efea4af5a1ec81",
    "url": "img/aw.d536ae24.svg"
  },
  {
    "revision": "93d4994bf0c2670aea991618878b0688",
    "url": "img/az.93d4994b.svg"
  },
  {
    "revision": "f92494b7a31b30b018c0e8bcfa5690b1",
    "url": "img/ba.f92494b7.svg"
  },
  {
    "revision": "1db266d702c39d521b38ef7578e89cee",
    "url": "img/bb.1db266d7.svg"
  },
  {
    "revision": "7e397372fec8c88f49ba97a536880e70",
    "url": "img/bb02-pw-entry.7e397372.gif"
  },
  {
    "revision": "33b0d66b6977a92a2b833435cd53d44a",
    "url": "img/bd.33b0d66b.svg"
  },
  {
    "revision": "179a6a5d6b443cf0005a6049c110b269",
    "url": "img/bg-404.179a6a5d.svg"
  },
  {
    "revision": "581517c8a536ca0b28249ae41ee62f28",
    "url": "img/bg-bubbles.581517c8.png"
  },
  {
    "revision": "3f40a32ba7145d1b4196472b0c3db12c",
    "url": "img/bg-circle-triangle.3f40a32b.png"
  },
  {
    "revision": "a7a3632615a47f090a7758c9821d12e1",
    "url": "img/bg-dapps-center.a7a36326.png"
  },
  {
    "revision": "77d61caa462bc75166f33c2c562b0b5c",
    "url": "img/bg-erroe-msg.77d61caa.svg"
  },
  {
    "revision": "13c2a11df9d502808c4bcb5af55bef75",
    "url": "img/bg-half-circle.13c2a11d.png"
  },
  {
    "revision": "313ea5b0d4eb6bbc036bacce7a643231",
    "url": "img/bg-home-spaceman-and-dog.313ea5b0.svg"
  },
  {
    "revision": "71563aac8aef529254dfdd6450dea2c0",
    "url": "img/bg-homepage-spaceman-center.71563aac.svg"
  },
  {
    "revision": "499743647650fe33591001c56530d39b",
    "url": "img/bg-homepage.49974364.svg"
  },
  {
    "revision": "eef0d489c9b0d2d7b0cc17e08f1ddc07",
    "url": "img/bg-left-bubble.eef0d489.png"
  },
  {
    "revision": "a6098eb5c3840263c176efc8a2744840",
    "url": "img/bg-light.a6098eb5.jpg"
  },
  {
    "revision": "f8ae4bde273ba114cb4c38ac45945f5a",
    "url": "img/bg-mew-wallet.f8ae4bde.png"
  },
  {
    "revision": "9b9edde8c806e1f0f2a5463681715d84",
    "url": "img/bg-mountains.9b9edde8.png"
  },
  {
    "revision": "933d5f0be872ab3d11fea5af545cc7c9",
    "url": "img/bg-right-bubble.933d5f0b.png"
  },
  {
    "revision": "1a662794ded539c7dbf14830c54c25ad",
    "url": "img/bg-small-half-circle.1a662794.png"
  },
  {
    "revision": "ab600882659632fa9d41cc4b5930512d",
    "url": "img/bg-spaceman.ab600882.png"
  },
  {
    "revision": "50068b152544bc5b2c0b1c57f4248891",
    "url": "img/bg-unstoppable-domain.50068b15.png"
  },
  {
    "revision": "62a871a5f8e0e0186af772a3ce70e223",
    "url": "img/bg-waves-color.62a871a5.png"
  },
  {
    "revision": "e35f82f0efc9e86cb6295f9d30c32171",
    "url": "img/bg-waves.e35f82f0.svg"
  },
  {
    "revision": "0ef89f3e55e045c1e8e956c2a96da4ff",
    "url": "img/bg.0ef89f3e.svg"
  },
  {
    "revision": "4bc0dacd5d4dc23475bb441fd603bdd4",
    "url": "img/bh.4bc0dacd.svg"
  },
  {
    "revision": "761c83b881740e9c5109e0e5c6991828",
    "url": "img/bi.761c83b8.svg"
  },
  {
    "revision": "967e1f93f607f5ceb3f905fa658e606b",
    "url": "img/billfodl.967e1f93.png"
  },
  {
    "revision": "4885c18a2a8fe610c6a2240b149afc52",
    "url": "img/bitbox.4885c18a.png"
  },
  {
    "revision": "4b910905e64d565fe5d792e681a9ea5c",
    "url": "img/bitbox.4b910905.png"
  },
  {
    "revision": "1309a8a737d65ff13e7398f5d20cce83",
    "url": "img/bitbox02-locked.1309a8a7.png"
  },
  {
    "revision": "de769c0897eea0bc6db59b202b74b341",
    "url": "img/bitbox02-welcome.de769c08.png"
  },
  {
    "revision": "270e6de15cb7a7476b14476595bcebe1",
    "url": "img/bitmap.270e6de1.png"
  },
  {
    "revision": "65034eeae3ddbbdb27d4afa32f40a512",
    "url": "img/bm.65034eea.svg"
  },
  {
    "revision": "b463ac712d6e450623473a6352f82e2d",
    "url": "img/bn.b463ac71.svg"
  },
  {
    "revision": "2d373f6e99d7f6e1efa9b0d5dc76bffa",
    "url": "img/bo.2d373f6e.svg"
  },
  {
    "revision": "057f3318ec8094abfc02d746d78f167a",
    "url": "img/br.057f3318.svg"
  },
  {
    "revision": "6586394793869bfbc037ea7e98590bc3",
    "url": "img/brian.65863947.jpg"
  },
  {
    "revision": "884db4ca85e7c3dbfb2685386497ef1f",
    "url": "img/brionne.884db4ca.jpg"
  },
  {
    "revision": "f1e5a2375516bbd35149b64669f461e3",
    "url": "img/brittany.f1e5a237.jpg"
  },
  {
    "revision": "048f207088030e3c33408b18b4d40a0b",
    "url": "img/bs.048f2070.svg"
  },
  {
    "revision": "e5f46f6e50de67a1b3957b88ca771f53",
    "url": "img/bsc.e5f46f6e.svg"
  },
  {
    "revision": "c81d52f9807fa65b6be80c2266e91986",
    "url": "img/bt.c81d52f9.svg"
  },
  {
    "revision": "6e701c881452b39af84ab52fa1eece77",
    "url": "img/btc.6e701c88.png"
  },
  {
    "revision": "bad39c4fc54b296851beb629a134c4b8",
    "url": "img/button-app-store.bad39c4f.png"
  },
  {
    "revision": "cb4296cb7bc1207f61bcfbfe9166c1e3",
    "url": "img/button-app-store.cb4296cb.svg"
  },
  {
    "revision": "bc93cea11dca8d35b897ef58fe6a44c1",
    "url": "img/button-circle-right-arrow.bc93cea1.svg"
  },
  {
    "revision": "0b0baeb13a319a86d41b9efaa72c2848",
    "url": "img/button-play-store.0b0baeb1.png"
  },
  {
    "revision": "eb328107d90f67b82403c56936ad9888",
    "url": "img/button-play-store.eb328107.svg"
  },
  {
    "revision": "9a7528b95cea43526a82c052154e60fe",
    "url": "img/bw.9a7528b9.svg"
  },
  {
    "revision": "58ae33e6909cf72dbb9fd53faac7470f",
    "url": "img/by.58ae33e6.svg"
  },
  {
    "revision": "cbbe4ee809c535c1a329174cd5ee7f76",
    "url": "img/bz.cbbe4ee8.svg"
  },
  {
    "revision": "4d433fc3bd3b5568f93161a29400c73c",
    "url": "img/ca.4d433fc3.svg"
  },
  {
    "revision": "ad03efd05727acf3f5ea5b0b59266454",
    "url": "img/cd.ad03efd0.svg"
  },
  {
    "revision": "2255e54e479952ea56392f831b8abfd1",
    "url": "img/cf.2255e54e.svg"
  },
  {
    "revision": "fb3c1d5b2db862fe05d37362418de036",
    "url": "img/changelly.fb3c1d5b.png"
  },
  {
    "revision": "f71c13f1a0e69bf38854da0e7a94bdd8",
    "url": "img/chindalath.f71c13f1.jpg"
  },
  {
    "revision": "77bd1068fe0c37d99b033feb25af42b4",
    "url": "img/christian.77bd1068.jpg"
  },
  {
    "revision": "f385ab70102fc72a5cc57c67549471a7",
    "url": "img/ci.f385ab70.svg"
  },
  {
    "revision": "dfe5e4b9ad7f02d4196be54274b274c7",
    "url": "img/cl.dfe5e4b9.svg"
  },
  {
    "revision": "daa4b5a7e549d7f7897e5101f6dc5131",
    "url": "img/cn.daa4b5a7.svg"
  },
  {
    "revision": "27b71dc72631d9205fe646448225fed5",
    "url": "img/co.27b71dc7.svg"
  },
  {
    "revision": "826d1e727efb2e309c1134d3af122c56",
    "url": "img/coolwallet-sample.826d1e72.png"
  },
  {
    "revision": "3cd3d656625183291792aa8f67929da6",
    "url": "img/coolwallet.3cd3d656.svg"
  },
  {
    "revision": "2c8a0b157da53116fa90ba3424e7a386",
    "url": "img/cr.2c8a0b15.svg"
  },
  {
    "revision": "ced5bf8d4a51d9162a5d3e19d9f6545e",
    "url": "img/cu.ced5bf8d.svg"
  },
  {
    "revision": "4e54347bc13d4298ba84b506b4ba8366",
    "url": "img/cv.4e54347b.svg"
  },
  {
    "revision": "591673eebdcf515f5d5508add0fc009a",
    "url": "img/cz.591673ee.svg"
  },
  {
    "revision": "a214e7b4de1d36f7d52e97246dcaf06f",
    "url": "img/dai.a214e7b4.png"
  },
  {
    "revision": "947049c087c44f542bfedd37d3e7440a",
    "url": "img/david.947049c0.jpg"
  },
  {
    "revision": "1ae4c0f6d4facad34075252f928a0a82",
    "url": "img/dj.1ae4c0f6.svg"
  },
  {
    "revision": "37a1865895f22ddb0f0e1bd2970cf2c9",
    "url": "img/dk.37a18658.svg"
  },
  {
    "revision": "f03d42f0847440b58d374f7a04bc3ae6",
    "url": "img/dm.f03d42f0.svg"
  },
  {
    "revision": "c33b8d86bff9429da9d8a3eb4f71d745",
    "url": "img/do.c33b8d86.svg"
  },
  {
    "revision": "300c399075a5a11f90917c766f6a8566",
    "url": "img/dz.300c3990.svg"
  },
  {
    "revision": "662494cb6796d70cc87c894c3bc17bcd",
    "url": "img/eg.662494cb.svg"
  },
  {
    "revision": "bbe5c30ffe639317af1fd28b7ceae57b",
    "url": "img/eh.bbe5c30f.svg"
  },
  {
    "revision": "d7790c413c20478a2d03f83c5536fc6b",
    "url": "img/er.d7790c41.svg"
  },
  {
    "revision": "0dc00578ef7b9517ab80907ed7be589c",
    "url": "img/et.0dc00578.svg"
  },
  {
    "revision": "ad3bab0d4363ccc278de302e609bc7e7",
    "url": "img/etc.ad3bab0d.svg"
  },
  {
    "revision": "a1472dde86ed92f0a803a38690bb4ed4",
    "url": "img/eth-blocks-3.a1472dde.png"
  },
  {
    "revision": "53bb9341a74e6c26281afb4be800b991",
    "url": "img/eth-blocks-6.53bb9341.png"
  },
  {
    "revision": "46f7c5099e30b470f3f25995278adab1",
    "url": "img/eth-blocks-qrs.46f7c509.svg"
  },
  {
    "revision": "ad11058d846dfaab031d0beb1bf7ab33",
    "url": "img/eth-dark-navy.ad11058d.svg"
  },
  {
    "revision": "5b2fc1fc02a761c570ac10dab54a7b13",
    "url": "img/eth.5b2fc1fc.svg"
  },
  {
    "revision": "871ae2e7221011c886ebe7ea36787943",
    "url": "img/european_union.871ae2e7.svg"
  },
  {
    "revision": "1e88cb93e18df04a81857fc64ad6f75d",
    "url": "img/finney.1e88cb93.png"
  },
  {
    "revision": "7e97c105aef6cfb947821c2794b9cc15",
    "url": "img/fj.7e97c105.svg"
  },
  {
    "revision": "f287bd407dbc5555fd8c89946ffe8cc3",
    "url": "img/fk.f287bd40.svg"
  },
  {
    "revision": "a360457693ab501e4c42c4789c197b0f",
    "url": "img/gage.a3604576.jpg"
  },
  {
    "revision": "9cc7b318769486988bea20775a454a01",
    "url": "img/gamaliel.9cc7b318.jpg"
  },
  {
    "revision": "05a4a9027bfb21945e2c36bf225f35b1",
    "url": "img/gb.05a4a902.svg"
  },
  {
    "revision": "a5234f32d942ca46473c172450dd7003",
    "url": "img/ge.a5234f32.svg"
  },
  {
    "revision": "b21ce03150d5665b021de644291bbd5d",
    "url": "img/gh.b21ce031.svg"
  },
  {
    "revision": "fb52d8c2f2f4a837c89eb26a236c7813",
    "url": "img/gi.fb52d8c2.svg"
  },
  {
    "revision": "ddc250127189a3b4ee4802e6c2493757",
    "url": "img/github.ddc25012.svg"
  },
  {
    "revision": "e00cacd6dcf7f6b4a1c1caea6adf78d7",
    "url": "img/gm.e00cacd6.svg"
  },
  {
    "revision": "3f4a6d5a0b32d69bb017ec9d0aed3434",
    "url": "img/gn.3f4a6d5a.svg"
  },
  {
    "revision": "265cdedb938ea57e707ebce686a7f16f",
    "url": "img/go.265cdedb.svg"
  },
  {
    "revision": "4a13339fdb87a1ea1a22b24b7d5618a5",
    "url": "img/gp.4a13339f.svg"
  },
  {
    "revision": "c9385b061ee36b46006e063311c0d6b8",
    "url": "img/gt.c9385b06.svg"
  },
  {
    "revision": "3ac8d8fb43731497a59c3be6671efde5",
    "url": "img/gy.3ac8d8fb.svg"
  },
  {
    "revision": "7667be2ebe66da6b43405536358a48dc",
    "url": "img/hk.7667be2e.svg"
  },
  {
    "revision": "94abe2f41dbab8b161a979077d336d93",
    "url": "img/hn.94abe2f4.svg"
  },
  {
    "revision": "3c3cb4e0bb504066e5607df14d1f3b43",
    "url": "img/hr.3c3cb4e0.svg"
  },
  {
    "revision": "83223775ec37213f37d3b1c5599f9edd",
    "url": "img/ht.83223775.svg"
  },
  {
    "revision": "8f4c390339a02ee646bf06a7d3977502",
    "url": "img/hu.8f4c3903.svg"
  },
  {
    "revision": "cf6318aa0448611cc8adc9ee661ff2f4",
    "url": "img/icon-apple-pay.cf6318aa.svg"
  },
  {
    "revision": "5d8fadf4799eb02f12ee156c7623b617",
    "url": "img/icon-appstore-android-dark.5d8fadf4.svg"
  },
  {
    "revision": "63762eedd5c3f65e43b841d871a3ac02",
    "url": "img/icon-appstore-apple-dark.63762eed.svg"
  },
  {
    "revision": "ec7197eef11b774ef6023056cdb48501",
    "url": "img/icon-arrow-up.ec7197ee.svg"
  },
  {
    "revision": "38337a89f1921f14acf0444297ec28de",
    "url": "img/icon-bank.38337a89.svg"
  },
  {
    "revision": "3c28f39dceae0ce7c61ae342ac207042",
    "url": "img/icon-bitbox.3c28f39d.svg"
  },
  {
    "revision": "147159c088960505064d6b7d2ab7c522",
    "url": "img/icon-btc-gold.147159c0.svg"
  },
  {
    "revision": "9fb32c79b025aded08e47c363d61a289",
    "url": "img/icon-btc-white.9fb32c79.svg"
  },
  {
    "revision": "7551a462b6aff3a7cb12571940834b2f",
    "url": "img/icon-buy-eth-mew.7551a462.svg"
  },
  {
    "revision": "7749fb50b5f15e3356064f8fee3934ae",
    "url": "img/icon-buy-token-white.7749fb50.svg"
  },
  {
    "revision": "e1c3fc6320ba451eca4310d8f7508ab2",
    "url": "img/icon-checked.e1c3fc63.svg"
  },
  {
    "revision": "82aab93bf704145f8592fa2669896041",
    "url": "img/icon-colorful-eth.82aab93b.svg"
  },
  {
    "revision": "fe05f5ad03176bc82c1b173a4108f58e",
    "url": "img/icon-community-mew.fe05f5ad.svg"
  },
  {
    "revision": "9f009591109c1ceabd191f31f5237169",
    "url": "img/icon-contract-enable.9f009591.svg"
  },
  {
    "revision": "5cb59b0967509f7220ad1d002afd24b7",
    "url": "img/icon-contract-mew.5cb59b09.svg"
  },
  {
    "revision": "4c335d0a0fbc34b47013c05ff511b553",
    "url": "img/icon-coolwallet.4c335d0a.svg"
  },
  {
    "revision": "8901d68ccb7390a5b4d159db322d343d",
    "url": "img/icon-customer-support.8901d68c.svg"
  },
  {
    "revision": "e6d0abea1239f19ef566dc0ecee9d19e",
    "url": "img/icon-dapp-center-enable.e6d0abea.svg"
  },
  {
    "revision": "2836fa28ec95b2ee9005def3ef7aaff1",
    "url": "img/icon-dapp-eth-blocks.2836fa28.svg"
  },
  {
    "revision": "92b076a100f6db1a765d1a10e2eca41a",
    "url": "img/icon-dapp-eth.92b076a1.svg"
  },
  {
    "revision": "42849253626161960c34fe1578b6d1e0",
    "url": "img/icon-dapp-lock.42849253.png"
  },
  {
    "revision": "87c3600759fd8449d010d46c87731243",
    "url": "img/icon-dapp-makerdao.87c36007.png"
  },
  {
    "revision": "b96afc779c69e6c21734ddd2415fcea2",
    "url": "img/icon-dapps-mew.b96afc77.svg"
  },
  {
    "revision": "bef21fb5f1c4b702b741c084c1658028",
    "url": "img/icon-dashboard-enable.bef21fb5.svg"
  },
  {
    "revision": "b01b9c9dd7eb8f08fb3f225121cff624",
    "url": "img/icon-ens-manager-white-bg.b01b9c9d.svg"
  },
  {
    "revision": "e07b6c5e6be09e55ab79b58eb0af82c7",
    "url": "img/icon-eth-blocks-logo.e07b6c5e.png"
  },
  {
    "revision": "638adc7608aae1294d0e0333531c378b",
    "url": "img/icon-eth-blue.638adc76.svg"
  },
  {
    "revision": "c93dc3afed5bf5727d2108cc7fca7d37",
    "url": "img/icon-eth-gray.c93dc3af.svg"
  },
  {
    "revision": "a4ac3058baead0c79e75c4585bc0a544",
    "url": "img/icon-eth-grey.a4ac3058.svg"
  },
  {
    "revision": "a1338ac21d257a46ad81ffc4849bb011",
    "url": "img/icon-eth-white.a1338ac2.svg"
  },
  {
    "revision": "82d31ed7fbdb6f4a9518351cfab6b67a",
    "url": "img/icon-ethvm.82d31ed7.png"
  },
  {
    "revision": "7b784ab3f0d95aedc9cade90edd46008",
    "url": "img/icon-faces-mew.7b784ab3.svg"
  },
  {
    "revision": "2090db1ee97496b1015fcf33e7c048a3",
    "url": "img/icon-fiat-white.2090db1e.svg"
  },
  {
    "revision": "6a9b1969497fa9e1f86a93539bcf52b2",
    "url": "img/icon-github-dark.6a9b1969.svg"
  },
  {
    "revision": "90b98761215a6fab3b3667287760591d",
    "url": "img/icon-grid-dot-green.90b98761.svg"
  },
  {
    "revision": "63f3f69ff88822d814834c0b0751933f",
    "url": "img/icon-hardware-wallet.63f3f69f.png"
  },
  {
    "revision": "c6b6496fb8416be4467923eb9f320364",
    "url": "img/icon-keepkey.c6b6496f.svg"
  },
  {
    "revision": "956cbf72057a9c02cab8202b488ef993",
    "url": "img/icon-keystore-file.956cbf72.svg"
  },
  {
    "revision": "b4b1615e9417cf07b418258405607fc8",
    "url": "img/icon-keystore-mew.b4b1615e.png"
  },
  {
    "revision": "deac52f186c3f1aa2a17cf081bb85471",
    "url": "img/icon-ledger.deac52f1.svg"
  },
  {
    "revision": "f400612ba3c1a622157a95f786361a54",
    "url": "img/icon-logout-enable.f400612b.svg"
  },
  {
    "revision": "1b6f734fb927841750050bed2ef45532",
    "url": "img/icon-master.1b6f734f.svg"
  },
  {
    "revision": "58df497f6af904a1265cba50506fbdb0",
    "url": "img/icon-menu-buy-sell.58df497f.svg"
  },
  {
    "revision": "9c94ace6bc108c57e8b70b93669cdaf6",
    "url": "img/icon-menu-send.9c94ace6.svg"
  },
  {
    "revision": "0a7fb61c951fba337557d789ce8c3329",
    "url": "img/icon-menu-swap.0a7fb61c.svg"
  },
  {
    "revision": "959d240677f788e50cff3d00081a04ae",
    "url": "img/icon-menu.959d2406.svg"
  },
  {
    "revision": "4659e71354b9fb9ff6b21b44abb6e63a",
    "url": "img/icon-message-enable.4659e713.svg"
  },
  {
    "revision": "ec409d6dfc8c6912713160507505c2c0",
    "url": "img/icon-message-mew.ec409d6d.svg"
  },
  {
    "revision": "1b2f87fd48c70c704dcb978eae71d99f",
    "url": "img/icon-message2-mew.1b2f87fd.svg"
  },
  {
    "revision": "ece1afecfd69b13382c4db0616a03f9a",
    "url": "img/icon-mew-connect.ece1afec.png"
  },
  {
    "revision": "ef0ea2225214d534d84d2b051a7ed8c4",
    "url": "img/icon-mew-cx.ef0ea222.png"
  },
  {
    "revision": "4bdea8d3f8935fbdbb4367537eac4867",
    "url": "img/icon-mew-logo.4bdea8d3.svg"
  },
  {
    "revision": "f29574d35392dc86ba4124d1c8ba7938",
    "url": "img/icon-mew-wallet.f29574d3.png"
  },
  {
    "revision": "7c3d34fc57b200b5802a3431bf28392c",
    "url": "img/icon-mnemonic.7c3d34fc.svg"
  },
  {
    "revision": "97fed0106dc4c28183a31a3357f7fbe9",
    "url": "img/icon-nft-mew.97fed010.svg"
  },
  {
    "revision": "b2df08331800c0e8594f415b956472bb",
    "url": "img/icon-nft-placeholder.b2df0833.png"
  },
  {
    "revision": "e41ea50a4c7737c89ce13134b9c27169",
    "url": "img/icon-nft.e41ea50a.svg"
  },
  {
    "revision": "09e377beef5a4a9bb6582d3ddc0ab369",
    "url": "img/icon-notifications.09e377be.svg"
  },
  {
    "revision": "4f0c3f2d89a037f1b46e52250a633e9d",
    "url": "img/icon-offline-mew.4f0c3f2d.svg"
  },
  {
    "revision": "39552c75899bcaeb11d7099740fb943b",
    "url": "img/icon-party-popper.39552c75.png"
  },
  {
    "revision": "46f19317632e4f7fd4a875b4449be912",
    "url": "img/icon-puppy-mew.46f19317.svg"
  },
  {
    "revision": "75bf471c040e6a5338adae11b2b3b705",
    "url": "img/icon-reddit-dark.75bf471c.svg"
  },
  {
    "revision": "25273de8042491d1616da26eeddbea50",
    "url": "img/icon-send-enable.25273de8.svg"
  },
  {
    "revision": "c50441935f6f9f3044aec0e5a3ad8115",
    "url": "img/icon-send-mew.c5044193.svg"
  },
  {
    "revision": "481a1452254c2b88aa209f3437ea4f88",
    "url": "img/icon-setting-enable.481a1452.svg"
  },
  {
    "revision": "32cdf83cc553fa459a349d08a03c6155",
    "url": "img/icon-shield-checked.32cdf83c.svg"
  },
  {
    "revision": "30075a296d9b1fa79243d259b17c9d5a",
    "url": "img/icon-shield-crossed.30075a29.svg"
  },
  {
    "revision": "8ead6587bc0eb35c1120d0eb9d16da17",
    "url": "img/icon-shield.8ead6587.svg"
  },
  {
    "revision": "74d67081f94c2e93f4af95a4353dd101",
    "url": "img/icon-simplex.74d67081.svg"
  },
  {
    "revision": "4d66b3d4415db9ae40127abb513305c6",
    "url": "img/icon-slack-dark.4d66b3d4.svg"
  },
  {
    "revision": "881a57a1b8588f52602597f860beb9e3",
    "url": "img/icon-sotd.881a57a1.png"
  },
  {
    "revision": "ff0b23e648dd0cad686b2b544e6536eb",
    "url": "img/icon-stakewise-green.ff0b23e6.svg"
  },
  {
    "revision": "66546c2139b94af018982434eb07ba0a",
    "url": "img/icon-stakewise-purple.66546c21.svg"
  },
  {
    "revision": "b061391f0999a0021f5270c890a88b5f",
    "url": "img/icon-stakewise-red.b061391f.svg"
  },
  {
    "revision": "bf286d013f3dd4248924f34056db5787",
    "url": "img/icon-submit-mew.bf286d01.svg"
  },
  {
    "revision": "fadaebc325afe719ac802093ecefdb55",
    "url": "img/icon-support.fadaebc3.svg"
  },
  {
    "revision": "ce4de633b057048f5efc037b07924d74",
    "url": "img/icon-swap.ce4de633.svg"
  },
  {
    "revision": "6ec8ec13ee5658892c4df4aa6d00e7d4",
    "url": "img/icon-telegram-dark.6ec8ec13.svg"
  },
  {
    "revision": "fa55267a18a46746bbd3b7361ae03e74",
    "url": "img/icon-telegram.fa55267a.svg"
  },
  {
    "revision": "19f6da90b15d9f3a079145bcba92a745",
    "url": "img/icon-trezor.19f6da90.svg"
  },
  {
    "revision": "201a190a28ace4f00bb3b45255d164a6",
    "url": "img/icon-visa-dark.201a190a.png"
  },
  {
    "revision": "6eddd303fb47ba79fefe7fee108110aa",
    "url": "img/icon-visa.6eddd303.svg"
  },
  {
    "revision": "fde9097f71fd4c3228bd2ebc26097ff5",
    "url": "img/icon-wallet-connect.fde9097f.svg"
  },
  {
    "revision": "af4ad70ad3574b9ad11858824985d7d7",
    "url": "img/icon-wallet-link.af4ad70a.png"
  },
  {
    "revision": "29d7dbd5af98200ee68517c4be6b94f0",
    "url": "img/id.29d7dbd5.svg"
  },
  {
    "revision": "1243ac49f28c1f43856bbcf2d648af53",
    "url": "img/il.1243ac49.svg"
  },
  {
    "revision": "f7e83cac25acaffcd543c34025c3d1f1",
    "url": "img/im.f7e83cac.svg"
  },
  {
    "revision": "0885ff7d2ac292fcd7cdd5dacef7f4e4",
    "url": "img/iq.0885ff7d.svg"
  },
  {
    "revision": "9219b4a55203ac0d093b4af13728e384",
    "url": "img/ir.9219b4a5.svg"
  },
  {
    "revision": "9e18eabf2cdfada2761be0d08414f937",
    "url": "img/is.9e18eabf.svg"
  },
  {
    "revision": "17f39c56f96c760fad03744e8768b706",
    "url": "img/jason.17f39c56.jpg"
  },
  {
    "revision": "48c91f5c320177aeaa06c1becc696553",
    "url": "img/jazmine.48c91f5c.jpg"
  },
  {
    "revision": "db9c6cf00b28c9b3f6c54b2753835364",
    "url": "img/je.db9c6cf0.svg"
  },
  {
    "revision": "9d4a1bc69652a0e9c4eb657be8224793",
    "url": "img/jm.9d4a1bc6.svg"
  },
  {
    "revision": "837db7446e42e59431d8f9a3bb7ff6b0",
    "url": "img/jo.837db744.svg"
  },
  {
    "revision": "be04fd894b0d6e13a16ec1bb874b74e2",
    "url": "img/jp.be04fd89.svg"
  },
  {
    "revision": "5568ca5a18d8f575357375674a9b1cfd",
    "url": "img/katya.5568ca5a.jpg"
  },
  {
    "revision": "c0bf589a9511a36bea87979ee4c1c3d1",
    "url": "img/ke.c0bf589a.svg"
  },
  {
    "revision": "4c66604602613def42e0169a081fc57b",
    "url": "img/keepkey.4c666046.svg"
  },
  {
    "revision": "82bc8ace7015634f2f8ed9d11e3232fd",
    "url": "img/keepkey.82bc8ace.png"
  },
  {
    "revision": "d7083f29423b7fcfcf7de2225973f9a4",
    "url": "img/keepkey.d7083f29.png"
  },
  {
    "revision": "cd9a1369e46f9f15eac85270c140bd1e",
    "url": "img/keystore-file.cd9a1369.jpg"
  },
  {
    "revision": "a92b7300128c8005e1109ee88f0619b8",
    "url": "img/kg.a92b7300.svg"
  },
  {
    "revision": "3a7a7d57d2692b90ec3663b258211ba0",
    "url": "img/kh.3a7a7d57.svg"
  },
  {
    "revision": "4a12bb178db2290729910f61273aeff7",
    "url": "img/km.4a12bb17.svg"
  },
  {
    "revision": "b54765292d1b9d2d994bfb7e74097223",
    "url": "img/knc.b5476529.png"
  },
  {
    "revision": "5cb7cc31915d297f22d7a979c2341968",
    "url": "img/kosala.5cb7cc31.jpg"
  },
  {
    "revision": "32070bf9c925fbd1a945013d4056987e",
    "url": "img/kp.32070bf9.svg"
  },
  {
    "revision": "4d7928d0e2aa321ec4f212ce0100cc6c",
    "url": "img/kr.4d7928d0.svg"
  },
  {
    "revision": "f236070f2b656334445a684af35fa9be",
    "url": "img/kw.f236070f.svg"
  },
  {
    "revision": "144850afa8deb943b589b0cf6341ab4f",
    "url": "img/ky.144850af.svg"
  },
  {
    "revision": "6105a9fecb7c006a7d0fd6789c1d9ece",
    "url": "img/kyber.6105a9fe.png"
  },
  {
    "revision": "3d973b6d79281a3fb5b92f1c5a560ecd",
    "url": "img/kz.3d973b6d.svg"
  },
  {
    "revision": "c86fffbfeb449e1b591d859528de4129",
    "url": "img/la.c86fffbf.svg"
  },
  {
    "revision": "107c3be9d99f0b4c4ed4f9933d383928",
    "url": "img/lb.107c3be9.svg"
  },
  {
    "revision": "237838237ac9c99226901f74d5d015a6",
    "url": "img/ledger-graphic.23783823.svg"
  },
  {
    "revision": "1a5ee423e4737e8b9e2d95119eb3960c",
    "url": "img/ledger.1a5ee423.png"
  },
  {
    "revision": "5dfe2fc447022e70355a8588c1e1cd8a",
    "url": "img/ledger.5dfe2fc4.svg"
  },
  {
    "revision": "535b82bf7e54c3f803e1416c665e00e9",
    "url": "img/li.535b82bf.svg"
  },
  {
    "revision": "4ad2e0789e92e692a58f237f80c3b9c9",
    "url": "img/link.4ad2e078.png"
  },
  {
    "revision": "9e0e66b47d769e0debc739a9a887d09e",
    "url": "img/lk.9e0e66b4.svg"
  },
  {
    "revision": "5d6f3213f637fb58626f8b06a8a156e7",
    "url": "img/loading-block.5d6f3213.svg"
  },
  {
    "revision": "517f1a5f7155326fd1041a3740e69950",
    "url": "img/logo-billfodl.517f1a5f.png"
  },
  {
    "revision": "a3abdc592bddf9d5ea469d0915eff8b1",
    "url": "img/logo-dark.a3abdc59.svg"
  },
  {
    "revision": "b47b5639868818bd4096e92168838b2d",
    "url": "img/logo-dark.b47b5639.png"
  },
  {
    "revision": "35affe8ada874b588486cedb1fa972dd",
    "url": "img/logo-kid.35affe8a.png"
  },
  {
    "revision": "683cb081dcc86d55df3f96c34b44c845",
    "url": "img/logo-kid.683cb081.svg"
  },
  {
    "revision": "029667b470bbb61f6467fbc8b268f5e5",
    "url": "img/logo-ledger.029667b4.svg"
  },
  {
    "revision": "49b9bcd4463fd2e903a70283c2399567",
    "url": "img/logo-light.49b9bcd4.svg"
  },
  {
    "revision": "7844737a280ad3b6f1b257c8fc635014",
    "url": "img/logo-light.7844737a.png"
  },
  {
    "revision": "5d962d4eff6f2256e53098aae5a360cd",
    "url": "img/logo-mew-dark.5d962d4e.png"
  },
  {
    "revision": "f6482e988b9598d015d4e039c996e69b",
    "url": "img/logo-mew.f6482e98.svg"
  },
  {
    "revision": "5d5fcba7727d9e91c871ccc4d6b11107",
    "url": "img/logo-simple.5d5fcba7.png"
  },
  {
    "revision": "88d6befc6b8f51a36c02ffa789a6a557",
    "url": "img/logo-simple.88d6befc.svg"
  },
  {
    "revision": "7d1254f16244917aff0f7dc0a1e06e24",
    "url": "img/logo-trezor.7d1254f1.svg"
  },
  {
    "revision": "03762e2d6b0bc5ec8323aa28ef04a9a8",
    "url": "img/lr.03762e2d.svg"
  },
  {
    "revision": "fa89864d6c4c887dbcce727bc039687b",
    "url": "img/ls.fa89864d.svg"
  },
  {
    "revision": "793eda52fd8268ea8c2a0ba876fcbbb5",
    "url": "img/lt.793eda52.svg"
  },
  {
    "revision": "9697c1c57eea9b2b50ed6761e7cbdefb",
    "url": "img/lv.9697c1c5.svg"
  },
  {
    "revision": "df3155b98edf6e141f67663c2ffaf352",
    "url": "img/ly.df3155b9.svg"
  },
  {
    "revision": "3a0be2cac77d9a789a132021f982fa2a",
    "url": "img/marcus.3a0be2ca.jpg"
  },
  {
    "revision": "78bf8d48a34cfe735f816fa40740af5f",
    "url": "img/matic.78bf8d48.svg"
  },
  {
    "revision": "667635e5a977946f3c551db63d2f6688",
    "url": "img/md.667635e5.svg"
  },
  {
    "revision": "a7f91db68b4b933c5d6825dfb10bcd69",
    "url": "img/metamask.a7f91db6.svg"
  },
  {
    "revision": "5b115a094d032013e9a3abba61868ff8",
    "url": "img/mew-collage-small.5b115a09.jpg"
  },
  {
    "revision": "00bbf48278a7812b4f80c3015f0090ab",
    "url": "img/mewwallet.00bbf482.svg"
  },
  {
    "revision": "8785f8d07da272f1fec074ac178ace2f",
    "url": "img/mg.8785f8d0.svg"
  },
  {
    "revision": "d7e96ee32741923da0b538f5b40a5716",
    "url": "img/michael.d7e96ee3.jpg"
  },
  {
    "revision": "ce98ec9ffbd7d3ff1247742f9eaaf7f6",
    "url": "img/mintme.ce98ec9f.svg"
  },
  {
    "revision": "027995cc4b666d55b17eec6725e0761e",
    "url": "img/misha.027995cc.jpg"
  },
  {
    "revision": "8e28b928e1f35b8077b91e10f790dd0e",
    "url": "img/mk.8e28b928.svg"
  },
  {
    "revision": "e1e9937625af45d6d6c72e0b02084123",
    "url": "img/mm.e1e99376.svg"
  },
  {
    "revision": "ab522741021a33c88f45a1d2b0d9ac50",
    "url": "img/mn.ab522741.svg"
  },
  {
    "revision": "a829e8877bcb790849dd4c682fbdfd39",
    "url": "img/mo.a829e887.svg"
  },
  {
    "revision": "4d8512231cb8f1d14f7220b225391c34",
    "url": "img/mobile-features-dapps.4d851223.svg"
  },
  {
    "revision": "3db0ebbdad96d9803bb07e1fbbe8d4ec",
    "url": "img/mobile-features-send.3db0ebbd.svg"
  },
  {
    "revision": "a15d3ab4af7cdf6ff29c08941bb08774",
    "url": "img/mobile-features-swap.a15d3ab4.svg"
  },
  {
    "revision": "22e08831c2f1170e4f77635f2b63be97",
    "url": "img/mobile-features-tokens.22e08831.svg"
  },
  {
    "revision": "3b4f187b430bf860d7dfb707a6e8adc4",
    "url": "img/moonbeam.3b4f187b.svg"
  },
  {
    "revision": "ac396b59bbb970e4a4269d51eac77679",
    "url": "img/moonpay-logo.ac396b59.svg"
  },
  {
    "revision": "037002eb35ada3e6e6576901f167d7ba",
    "url": "img/moonriver.037002eb.svg"
  },
  {
    "revision": "c94614cf0ac44e46ee110c4f1f942f4e",
    "url": "img/mr.c94614cf.svg"
  },
  {
    "revision": "e7b1ed616794d3825927189f83d19328",
    "url": "img/mu.e7b1ed61.svg"
  },
  {
    "revision": "e96351fd6c8807774d96f08d1e84933c",
    "url": "img/mv.e96351fd.svg"
  },
  {
    "revision": "821bfec12652e2deb9ed052774e93a50",
    "url": "img/mw.821bfec1.svg"
  },
  {
    "revision": "3ec0ef90ee44d55257594e5b320af639",
    "url": "img/mx.3ec0ef90.svg"
  },
  {
    "revision": "a3deeb7c82c658629c98830478476703",
    "url": "img/my-tokens-table.a3deeb7c.svg"
  },
  {
    "revision": "af3c3e9b290175550cb7a19b7721ccb5",
    "url": "img/my.af3c3e9b.svg"
  },
  {
    "revision": "f104942234e651bf0c8ebca00ff5ae29",
    "url": "img/mz.f1049422.svg"
  },
  {
    "revision": "d1ebb4bd2c2097be74d64f8882d6997e",
    "url": "img/na.d1ebb4bd.svg"
  },
  {
    "revision": "e4671de22b4d3f1104fe71ebee5ca792",
    "url": "img/network.e4671de2.svg"
  },
  {
    "revision": "9ddaa47c3c8857309ecf26eb30ec57d6",
    "url": "img/new-dapps-page.9ddaa47c.png"
  },
  {
    "revision": "c0bf7d8ff246d7982d558d6de884ffab",
    "url": "img/ng.c0bf7d8f.svg"
  },
  {
    "revision": "704a21bf8b7aaec1f3e004ff27f8166d",
    "url": "img/ni.704a21bf.svg"
  },
  {
    "revision": "6ad5392835cd9033852886113806ede5",
    "url": "img/no.6ad53928.svg"
  },
  {
    "revision": "1452f3dc94aabc6adf348d364d3c9e2a",
    "url": "img/np.1452f3dc.svg"
  },
  {
    "revision": "e7d2be7eedbe08c3c6f9e1fce5d9db44",
    "url": "img/nz.e7d2be7e.svg"
  },
  {
    "revision": "fbe76ba406d8e962da7992421e6a0fb9",
    "url": "img/olga.fbe76ba4.jpg"
  },
  {
    "revision": "957fa2cc624a8264e6335f7fb2d94dad",
    "url": "img/om.957fa2cc.svg"
  },
  {
    "revision": "9904c98ff645a433a5865a46069e3fb0",
    "url": "img/pa.9904c98f.svg"
  },
  {
    "revision": "4dc8e36944d2598315469fdf8ecefb31",
    "url": "img/paraswap.4dc8e369.png"
  },
  {
    "revision": "c96225a37b5c24767640100c52467d5d",
    "url": "img/pe.c96225a3.svg"
  },
  {
    "revision": "c7c6415305f2bca597407a9d9444ce44",
    "url": "img/pg.c7c64153.svg"
  },
  {
    "revision": "ba804bbacdfd3c3b99fe06f8e70f160e",
    "url": "img/ph.ba804bba.svg"
  },
  {
    "revision": "8e1b819cec9ac503c212583bcfdbbb0b",
    "url": "img/pk.8e1b819c.svg"
  },
  {
    "revision": "dab68e3036fcb93a86f919d80839319c",
    "url": "img/pl.dab68e30.svg"
  },
  {
    "revision": "8366490e6ff5a9d5369521de52d84b38",
    "url": "img/placeholder.8366490e.jpg"
  },
  {
    "revision": "bb1899d3a8c7fb2c2ae0b8495b093fad",
    "url": "img/py.bb1899d3.svg"
  },
  {
    "revision": "97b9b44e33ccbbe459a0e3fda97d9f18",
    "url": "img/qa.97b9b44e.svg"
  },
  {
    "revision": "20ce3720f9e6f54808c97d9e052e5a5d",
    "url": "img/raden.20ce3720.jpg"
  },
  {
    "revision": "2f564a768af6a5f9bde60b119ac42e70",
    "url": "img/richie.2f564a76.jpg"
  },
  {
    "revision": "feb88609ec1d6966b5ac0cffb888cef0",
    "url": "img/ro.feb88609.svg"
  },
  {
    "revision": "bdd892cdf337fc8975aca7ccab6ea06c",
    "url": "img/roboto-v20-latin-100.bdd892cd.svg"
  },
  {
    "revision": "dd0bea1f9a808d633492fa573039ca1d",
    "url": "img/roboto-v20-latin-300.dd0bea1f.svg"
  },
  {
    "revision": "95204ac95130828753c0ee0ada537c33",
    "url": "img/roboto-v20-latin-500.95204ac9.svg"
  },
  {
    "revision": "57888be7f3e68a7050452ea3157cf4de",
    "url": "img/roboto-v20-latin-700.57888be7.svg"
  },
  {
    "revision": "9c4bedeee9074a7ab438ff0e548d0fba",
    "url": "img/roboto-v20-latin-900.9c4bedee.svg"
  },
  {
    "revision": "8681f434273fd6a267b1a16a035c5f79",
    "url": "img/roboto-v20-latin-regular.8681f434.svg"
  },
  {
    "revision": "437d85037d8ba5d4e4158b085687a5d8",
    "url": "img/rs.437d8503.svg"
  },
  {
    "revision": "b7e32f2afc2bc24a4d45cec6fabd384d",
    "url": "img/ru.b7e32f2a.svg"
  },
  {
    "revision": "b8ec49ee738a99917c512eefcbac9db8",
    "url": "img/russell.b8ec49ee.jpg"
  },
  {
    "revision": "408bebb0110eca4e236ce302ef3688d1",
    "url": "img/rw.408bebb0.svg"
  },
  {
    "revision": "6a6a776e6eafd7894a15b59489d256e0",
    "url": "img/sa.6a6a776e.svg"
  },
  {
    "revision": "b3481d949279ba4bfabe1ab5b64ce61c",
    "url": "img/sb.b3481d94.svg"
  },
  {
    "revision": "bc08a6b5a14fc42c3b05d519ec6f810b",
    "url": "img/sc.bc08a6b5.svg"
  },
  {
    "revision": "3aa7c54abc6030365f7aaa3066358463",
    "url": "img/sd.3aa7c54a.svg"
  },
  {
    "revision": "01887b79a05dc88a4c59f3dc8ce2bf97",
    "url": "img/se.01887b79.svg"
  },
  {
    "revision": "612bc13eb11188fe020b107d1672e451",
    "url": "img/semaja.612bc13e.jpg"
  },
  {
    "revision": "b4373e7b8bfbaa94f2d6a8ad1b933b59",
    "url": "img/send-tx-page.b4373e7b.png"
  },
  {
    "revision": "ac975d1a1ef9f8a921c84454b401c9ef",
    "url": "img/sg.ac975d1a.svg"
  },
  {
    "revision": "ef084bfd8dea233d2d4e568e2b7bca24",
    "url": "img/simplex.ef084bfd.png"
  },
  {
    "revision": "89f0fd941a585cca4c263d3c61e3c365",
    "url": "img/sirin.89f0fd94.png"
  },
  {
    "revision": "2af9e36c64afa58914ebc21e2d0d51bc",
    "url": "img/skale.2af9e36c.svg"
  },
  {
    "revision": "b40874c7aad54ff1696b0c1828611780",
    "url": "img/sl.b40874c7.svg"
  },
  {
    "revision": "a52b3d53ae32eb0e55a23c04bc953dba",
    "url": "img/snippet-mew-wallet-confetti.a52b3d53.png"
  },
  {
    "revision": "ba052f96bb8187d86389a0ec479be9c7",
    "url": "img/so.ba052f96.svg"
  },
  {
    "revision": "183a9e40141ef7a6c92f9bbbb8144385",
    "url": "img/sr.183a9e40.svg"
  },
  {
    "revision": "1403f2d22c59133494fd9ebe2ddff95a",
    "url": "img/st.1403f2d2.svg"
  },
  {
    "revision": "e78b64970f591854b6087c6a92ae9134",
    "url": "img/sv.e78b6497.svg"
  },
  {
    "revision": "4bd06de5220da1881da65639f200c820",
    "url": "img/swap-arrow.4bd06de5.svg"
  },
  {
    "revision": "db1544a42048ea3093180014cc370c75",
    "url": "img/swap-page.db1544a4.png"
  },
  {
    "revision": "1228f6668ea3b3c79d212bdeb4b44e3c",
    "url": "img/sx.1228f666.svg"
  },
  {
    "revision": "366d1ac83c492cb1835ff481f6a1bc65",
    "url": "img/sy.366d1ac8.svg"
  },
  {
    "revision": "287333f40e1b6e6705160c45a4331253",
    "url": "img/sz.287333f4.svg"
  },
  {
    "revision": "f213dbbef7b45a13ca72862af6e662d3",
    "url": "img/th.f213dbbe.svg"
  },
  {
    "revision": "6f83dc6a5c45754ec89e5ed62aea63e6",
    "url": "img/tj.6f83dc6a.svg"
  },
  {
    "revision": "b792aa429b9486d200810ee496f6dc7e",
    "url": "img/tm.b792aa42.svg"
  },
  {
    "revision": "5c013018d4d863aa7928a5d94a16e287",
    "url": "img/tn.5c013018.svg"
  },
  {
    "revision": "5cba98ad640082174f6bdceeb622decf",
    "url": "img/to.5cba98ad.svg"
  },
  {
    "revision": "b4a158322e521d3a0ec446c0fbd07ca0",
    "url": "img/tr.b4a15832.svg"
  },
  {
    "revision": "3ae90c9908ceb97a350ffde954d36134",
    "url": "img/trezor.3ae90c99.svg"
  },
  {
    "revision": "c66f52ae0b4ec776d44d6ed0ae27ec98",
    "url": "img/trezor.c66f52ae.png"
  },
  {
    "revision": "ee80b6dceb1902699c325854e3a3b34f",
    "url": "img/tt.ee80b6dc.svg"
  },
  {
    "revision": "14f54b5d50dd9c9d673ef21ac481e1af",
    "url": "img/tw.14f54b5d.svg"
  },
  {
    "revision": "f56b4e238b58b0fb4098cb8bee546155",
    "url": "img/tz.f56b4e23.svg"
  },
  {
    "revision": "6ef59119c38bc5e1eb860bd17fdfa84b",
    "url": "img/ua.6ef59119.svg"
  },
  {
    "revision": "abab7fff91573ff833850f9d8b42f1e1",
    "url": "img/ug.abab7fff.svg"
  },
  {
    "revision": "d407a8e8013afe37d851d6dfd10eb209",
    "url": "img/uniswap.d407a8e8.png"
  },
  {
    "revision": "5947945ea95bcf3707ff61470c6972e8",
    "url": "img/us.5947945e.svg"
  },
  {
    "revision": "5aede8c5fd6c0298e235871b2fcc757b",
    "url": "img/usdc.5aede8c5.png"
  },
  {
    "revision": "0f48e38b7cfe58591814f96c623fb4e2",
    "url": "img/usdt.0f48e38b.png"
  },
  {
    "revision": "6720b2e47fdadc2c3921cd44e05689aa",
    "url": "img/uy.6720b2e4.svg"
  },
  {
    "revision": "2c99360b398906120f6265a5a5915c36",
    "url": "img/uz.2c99360b.svg"
  },
  {
    "revision": "6f3250ea4752641871f933f0c98cfba1",
    "url": "img/ve.6f3250ea.svg"
  },
  {
    "revision": "0cb21e89ef1f8a17339e2bb16c6fd708",
    "url": "img/vince.0cb21e89.jpg"
  },
  {
    "revision": "4bc2a5601a76d831d6d55ea857f8b4c6",
    "url": "img/vn.4bc2a560.svg"
  },
  {
    "revision": "e2349f70ba865da34faf0e3f0502af3c",
    "url": "img/vu.e2349f70.svg"
  },
  {
    "revision": "37f2bc6ecee2eb29b3cf6799ce58bf58",
    "url": "img/walletconnect.37f2bc6e.svg"
  },
  {
    "revision": "0b619167f601e6355364c4f63f0ca166",
    "url": "img/walletlink.0b619167.png"
  },
  {
    "revision": "ea5aa6c3d745bc9e5bc4e62c37da4931",
    "url": "img/wf.ea5aa6c3.svg"
  },
  {
    "revision": "e03072bc05344ccd2fea95e8f8cc63cc",
    "url": "img/ws.e03072bc.svg"
  },
  {
    "revision": "d62f817e0fe784988015a8871d6255a7",
    "url": "img/xblaster.d62f817e.png"
  },
  {
    "revision": "121e00c207252fa5608b96b75ab24599",
    "url": "img/xdc.121e00c2.svg"
  },
  {
    "revision": "c8aadcdaab6af181bcfc4d0d79b2f7e2",
    "url": "img/ye.c8aadcda.svg"
  },
  {
    "revision": "06e2a985bb77f9f5fa3adc6496d4452a",
    "url": "img/za.06e2a985.svg"
  },
  {
    "revision": "f6c0ef98ed3bbce0d3383c35217256f0",
    "url": "img/zm.f6c0ef98.svg"
  },
  {
    "revision": "76db6ed54a43d69822a861e69eff055d",
    "url": "img/zw.76db6ed5.svg"
  },
  {
    "revision": "cc102e0ab16352ff563169509c23a881",
    "url": "index.css"
  },
  {
    "revision": "e71eb6ed1f85792a70a4491385f47319",
    "url": "index.html"
  },
  {
    "revision": "42ce60b6c41b78595748",
    "url": "js/app~d0ae3f07.86a0c240.js"
  },
  {
    "revision": "863cf7cd62b0031b6c4c",
    "url": "js/chunk-062539e4.65b331e2.js"
  },
  {
    "revision": "145ba7b524ed9fc2ca55",
    "url": "js/chunk-1c9e159c.1234de78.js"
  },
  {
    "revision": "6d931b592a53533303c4",
    "url": "js/chunk-340c87db.ed82a827.js"
  },
  {
    "revision": "9ff236b7bbca13064315",
    "url": "js/chunk-3fe53b27.bf5b280a.js"
  },
  {
    "revision": "3c1b0eae90f98d488ef5",
    "url": "js/chunk-40a1a683.ac0411e3.js"
  },
  {
    "revision": "8bef9ce7d375ccecd19c",
    "url": "js/chunk-4a3513d9.381dacca.js"
  },
  {
    "revision": "e4d95b360bd238f60566",
    "url": "js/chunk-5b853063.07145825.js"
  },
  {
    "revision": "531d08620a538334fa07",
    "url": "js/chunk-5b8767bd.d1a6c764.js"
  },
  {
    "revision": "67b9440b55137775cbd1",
    "url": "js/chunk-715342ac.7c034021.js"
  },
  {
    "revision": "7303155f61f9d8eca2c2",
    "url": "js/chunk-734800ce.e6f17773.js"
  },
  {
    "revision": "3ea922202eb9f91b42ef",
    "url": "js/chunk-7482d6b4.6c367895.js"
  },
  {
    "revision": "badfcf25e17d7f8f3a66",
    "url": "js/chunk-88c27baa.c5d793ad.js"
  },
  {
    "revision": "f4eb9e6b2abe7591ed60",
    "url": "js/chunk-8e5acde4.b94fabd9.js"
  },
  {
    "revision": "b3816157884fe4fa7a22",
    "url": "js/chunk-e5a65756.e23ffe54.js"
  },
  {
    "revision": "1baca30ffda1ffccdc7c",
    "url": "js/chunk-ffafa6bc.01e99b31.js"
  },
  {
    "revision": "16685e735e7c7ea5fbcc022b6bac923f",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "95f84509fae8191ea04b3936d704887a",
    "url": "spaceman.png"
  }
]);